"""El valor de ‘¡HI TuNombre!’ imprimirlo por pantalla, el texto debe ser un string y
deberás guardarlo en una variable llamada mi_saludo. Tu nombre debe estar en otra
variable."""

mi_nombre = "Giancarlo"

mi_saludo = "¡Hi {}!".format(mi_nombre)

print(mi_saludo)