"""Crear un diccionario con los siguientes key: nombre, carrera, edad y año de
nacimiento, mostrar en pantalla el valor de este diccionario."""

diccionario = {"nombre": "Giancarlo", "carrera": "Ingenieria de Software", "edad": 19, "año de nacimiento": 2004}

print("Los valores de este diccionario son {},{},{},{}".format(diccionario["nombre"], diccionario["carrera"], diccionario["edad"], diccionario["año de nacimiento"]))