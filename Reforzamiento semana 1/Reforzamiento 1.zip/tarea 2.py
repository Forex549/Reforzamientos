"""Crea una variable tipo int. Luego, multiplica por 10 y restarle 10. Debes hacer todo
esto en dos pasos. Finalmente mostrar el resultado por pantalla."""

a = 5

resultado = (a * 10) - 10

print(resultado)