"""Crear una variable tipo string y poder luego sumarla con otra variable tipo int, para
esto convertir una de las variables. Mostrar la suma en pantalla."""

var_string = "Giancarlo"

var_int = 15

var_int = str(var_int)

print(var_int+var_string)