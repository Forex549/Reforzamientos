"""4.Hallar el volumen de una esfera, cada dato requerido para hallar el volumen debe
estar en una variable. Mostrar el volumen por pantalla."""

# V = 4/3*pi*r^3

r = 3

pi = 3.14

volumen = 4/3 * pi * (r**3)

print("El volumen es {} cm^3".format(volumen))

