"""Calcular la media de 5 datos (floats), cada dato debe estar en una variable y la media
también. Mostrar el resultado en pantalla."""

num1 = 15.5

num2 = 20.0

num3 = 46.9

num4 = 12.3

num5 = 80.6

suma = num1 + num2 + num3 + num4 + num5

media = suma/5

print("El resultado es {}".format(media))