"""De 3 números asignados (tú los propones) a 3 variables se pide hallar la suma de los
valores de los módulos con 3, 5, y 7 respectivamente, mostrar en pantalla el valor de la
suma."""
var_1 = 15

var_2 = 83

var_3 = 38

mod_1 = var_1 % 3

mod_2 = var_2 % 5

mod_3 = var_3 % 7

suma = mod_1 + mod_2 + mod_3

print("La suma es {}".format(suma))