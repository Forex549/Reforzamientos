"""Elevar al exponente de 4 un número que su valor estará asignado a una variable y
luego restar este mismo valor multiplicado por dos (usar pow). Mostrar el resultado en
pantalla."""

exponente = 3

valor = pow(4, exponente)-(exponente*2)

print("El valor final es {}".format(valor))